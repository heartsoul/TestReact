import {
    AppRegistry,
    Platform,
} from 'react-native';

// import App from './app/index'
import App from './app/redux/Root'

AppRegistry.registerComponent('DvaStarter', () => App)
