import React from 'react';
import {render} from 'react-dom';
// import App from './app/index'
import App from './app/redux/Root'

render(<App />, document.getElementById('root'));