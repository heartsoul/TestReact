"use strict";
import React, { Component } from "react";
import { Button,List,Picker,Result,Toast,Tabs,ImagePicker, WhiteSpace, Badge,ActionSheet,Accordion } from 'antd-mobile';
import {
    StyleSheet,
    Text,
    View,
    StatusBar,
    TouchableHighlight,
    Image,
    ImageBackground,
    Dimensions,
  } from 'react-native';
  const myImg = src => <Image source={{uri:src}} style={{width:60,height:60}} />;
  const data = [{
    url: 'https://zos.alipayobjects.com/rmsportal/PZUUCKTRIHWiZSY.jpeg',
    id: '2121',
  }, {
    url: 'https://zos.alipayobjects.com/rmsportal/hqQWgTXdrlmVVYi.jpeg',
    id: '2122',
  }];
export default class ANTD extends React.Component {
  showActionSheet = () => {
    
    const BUTTONS = ['Operation1', 'Operation2', 'Operation2', 'Delete', 'Cancel'];
    setTimeout(()=>{
      ActionSheet.showActionSheetWithOptions({
        options: BUTTONS,
        cancelButtonIndex: BUTTONS.length - 1,
        destructiveButtonIndex: BUTTONS.length - 2,
        title: 'title',
        message: 'I am description, description, description',
        maskClosable: true,
        'data-seed': 'logId',
        // wrapProps,
      },
      (buttonIndex) => {
        // this.setState({ clicked: BUTTONS[buttonIndex] });
      });
    }, 5)
    
  }
    renderContent = tab =>
    (<View style={{flex:1, alignItems: 'center', justifyContent: 'center', height: 150, backgroundColor: '#FFFFFF' }}>
      {/* <Text>Content of {tab.title}</Text> */}
    </View>);

    renderTabs() {
        const seasons = [
            [
              {
                label: '2013',
                value: '2013',
              },
              {
                label: '2014',
                value: '2014',
              },
            ],
            [
              {
                label: '春',
                value: '春',
              },
              {
                label: '夏',
                value: '夏',
              },
            ],
          ];
        const tabs = [
            { title: <Badge text={'3'}>First Tab</Badge> },
            { title: <Badge text={'今日(20)'}>Second Tab</Badge> },
            { title: <Badge dot>Third Tab</Badge> },
            { title: <Badge dot>Third Tab2</Badge> },
            { title: <Badge dot>Third Tab4</Badge> },
            { title: <Badge dot>Third Tab5</Badge> },
            
          ];
          
          const tabs2 = [
            { title: 'First Tab', sub: '1' },
            { title: 'Second Tab', sub: '2' },
            { title: 'Third Tab', sub: '3' },
          ];
          return (
            <View> 
    
    <Picker
          data={seasons}
          title="选择季节"
          cascade={false}
          extra="请选择(可选)"
        //   value={this.state.sValue}
        //   onChange={v => this.setState({ sValue: v })}
          onOk={v =>{ this.showActionSheet()}}
        >
          <List.Item arrow="horizontal">Multiple</List.Item>
        </Picker>
     <WhiteSpace />
    {/* <View style={{width:'100%',height:'20%'}} >
        <Tabs tabs={tabs} tabBarPosition="bottom" renderTabBar={props => <Tabs.DefaultTabBar {...props} page={3} />}>
          {this.renderContent}
        </Tabs> 
        </View> */}
         <View style={{width:'100%',height:44}} >
       {/* <Tabs style={{width:'100%',height:44}} tabs={tabs}
      initialPage={1}
      onChange={(tab, index) => { console.log('onChange', index, tab); }}
      onTabClick={(tab, index) => { console.log('onTabClick', index, tab); }}
    >
     <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center',width:200, height: 150, backgroundColor: '#fff' }}>
        <Text>Content of first tab</Text>
      </View>
      <View style={{flex: 1, alignItems: 'center', justifyContent: 'center',width:200, height: 150, backgroundColor: '#fff' }}>
      <Text>Content of first tab</Text>
      </View>
      <View style={{flex: 1, alignItems: 'center', justifyContent: 'center',width:200, height: 150, backgroundColor: '#fff' }}>
      <Text>Content of first tab</Text>
      </View>
    </Tabs> */}
    </View>
        <WhiteSpace />
        <Picker
          data={seasons}
          title="选择季节"
          cascade={false}
          extra="请选择(可选)"
        //   value={this.state.sValue}
        //   onChange={v => this.setState({ sValue: v })}
        //   onOk={v => this.setState({ sValue: v })}
        >
          <List.Item arrow="horizontal">Multiple</List.Item>
        </Picker>
        <Picker
          data={seasons}
          title="选择季节"
          cascade={false}
          extra="请选择(可选)"
        //   value={this.state.sValue}
        //   onChange={v => this.setState({ sValue: v })}
        //   onOk={v => this.setState({ sValue: v })}
        >
          <List.Item arrow="horizontal">Multiple</List.Item>
        </Picker>
    <Result
     img={myImg('https://gw.alipayobjects.com/zos/rmsportal/HWuSTipkjJRfTWekgTUG.svg')}
    title="等待处理"
    message="已提交申请，等待银行处理"
  />
  <ImagePicker
          files={data}
          onChange={this.onChange}
          onImageClick={(index, fs) => console.log(index, fs)}
          // selectable=true
          multiple={true}
        />
    <Button onClick={()=>{Toast.success('点击了我')}} >antd-mobile button</Button>
    <View style={{width:'100%',height:'20%'}}>
      <Accordion defaultActiveKey="0">
          <Accordion.Panel header="Title 1">
            <List className="my-list">
              <List.Item>content 1</List.Item>
              <List.Item>content 2</List.Item>
              <List.Item>content 3</List.Item>
            </List>
          </Accordion.Panel>
          <Accordion.Panel header="Title 2" className="pad">this is panel content2 or other</Accordion.Panel>
          <Accordion.Panel header="Title 3" className="pad">
            text text text text text text text text text text text text text text text
          </Accordion.Panel>
        </Accordion>
      </View>
            </View>
          )          
    }
    render() {
       return this.renderTabs();
      }
}

// .result-example .spe {
//     width: 60px;
//     height: 60px;
//   }
//   .sub-title {
//     color: #888;
//     font-size: 14px;
//     padding: 30px 0 18px 0;
//     margin-left: 15px;
//   }