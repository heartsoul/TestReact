import React, { Component } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
} from 'react-native';

import { connect } from 'react-redux'; // 引入connect函数
import *as loginAction from '../actions/loginAction';// 导入action方法
import { Redirect } from 'react-router-dom';
// // import { NavigationActions } from 'react-navigation';
// import MainPage from './MainPage';
// import { browserHistory } from 'react-router'
// const resetAction = NavigationActions.reset({
//     index: 0,
//     actions: [
//         browserHistory.push(`MainPage`)
//     ]
// })




class LoginPage extends Component {
    static navigationOptions = {
        title: 'LoginPage',
    };

    shouldComponentUpdate(nextProps, nextState) {
        // 登录完成,切成功登录
        if (nextProps.status === '登陆成功' && nextProps.isSuccess) {
            // this.props.navigation.dispatch(resetAction)
            // this.props.history.push("/Main")
            // setTimeout(()=>{
            //     console.log(this.props.history.push)
            //     this.props.history.push('/Main')
            // }, 5)
            console.log(this.props.history)
            if(this.props.history.location.pathname === '/Main') {
                return false;
            }
            this.props.history.replace('/Main')
            // browserHistory.push(`/MainPage`)
            return false;
        }
        return true;
    }

    render() {
        const { login } = this.props;
        // if(this.props.status === '登陆成功' && this.props.isSuccess) {
        //     return (
        //      <Redirect to="/Main"/>
        //     )
        //    }
        return (
            <View style={styles.container}>
                <Text>状态: {this.props.status}
                </Text>
                <TouchableOpacity onPress={() => login()} style={{ marginTop: 50 }}>
                    <View style={styles.loginBtn}>
                        <Text>登录
            </Text>
                    </View>
                </TouchableOpacity>
            </View>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#F5FCFF',
        height:'100%',
    },
    loginBtn: {
        borderWidth: 1,
        padding: 5,
    }
});

export default connect(
    (state) => ({
        status: state.loginIn.status,
        isSuccess: state.loginIn.isSuccess,
        user: state.loginIn.user,
    }),
    (dispatch) => ({
        login: () => dispatch(loginAction.login()),
    })
)(LoginPage)