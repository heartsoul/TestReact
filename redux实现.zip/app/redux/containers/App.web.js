import React, { Component } from 'react';
import {
  View,
  Text,
} from 'react-native';
// import { NativeRouter, Route,IndexRoute } from 'react-router-native'
import { BrowserRouter,Switch,Router,Route} from 'react-router-dom'
// import { syncHistoryWithStore } from 'react-router-redux'
// import { StackNavigator } from 'react-navigation';
import createBrowserHistory from 'history/createBrowserHistory'
import Loadable from 'react-loadable'

const history = createBrowserHistory();

import LoginPage from '../pages/LoginPage'
import MainPage from '../pages/MainPage'

const loadingComponent = ({ isLoading, error }) => {
    // Handle the loading state
    if (isLoading) {
        return <Text>Loading...</Text>;
    }
    // Handle the error state
    else if (error) {
        return <Text>Sorry, there was a problem loading the page.</Text>;
    }
    else {
        return null;
    }
  };

const Index = Loadable({
    loader: () => import('../pages/LoginPage'),
    loading: loadingComponent
  });
  const Login= Loadable({
    loader: () => import('../pages/LoginPage'),
    loading: loadingComponent
  });
const App = () => (
        <BrowserRouter>
        <View><Text>Sorry, there was a problem loading the page.</Text>
        <Route path="/" component={LoginPage}/>
        </View>
    </BrowserRouter>
);

export default App