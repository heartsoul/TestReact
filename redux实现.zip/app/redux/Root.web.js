import React, { Component } from 'react';
import {
    View,
    Text,
  } from 'react-native';
import { Provider } from 'react-redux';
import configureStore,{history} from './store/ConfigureStore';
import { Switch,NoMatch,Route} from 'react-router-dom'
// import { syncHistoryWithStore } from 'react-router-redux'
// import { StackNavigator } from 'react-navigation';
// import createBrowserHistory from 'history/createBrowserHistory'
import { ConnectedRouter } from 'connected-react-router'

import Loadable from 'react-loadable'
import LoginPage from './pages/LoginPage'
import MainPage from './pages/MainPage'
// const history = createBrowserHistory();
// import App from './containers/App';
const store = configureStore();

export default class Root extends Component {
  render() {
    return (
      <Provider store={store}>
       <ConnectedRouter history={history}>
        <Switch>
        <Route path="/" exact component={LoginPage}/>
        <Route path="/Login" exact component={LoginPage}/>
        <Route path="/Main" exact component={MainPage}/>
        <Route component={NoMatch}/>
        </Switch>
    </ConnectedRouter>
      </Provider>
    )
  }
}