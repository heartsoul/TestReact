import React from 'react';
import {Platform, Dimensions} from 'react-native';

const Util = {
  size: {
    width: 1000,// Dimensions.get('window').width,
    height: 1000,// Dimensions.get('window').height
  },
};

export default Util;