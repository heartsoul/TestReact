import { delay } from '../utils'

export const login = async () => {
  await delay(2000)
  return true
}
