// AlbumView.js

'use strict';

export default class AlbumView extends Component {
  render() {
  return <View><Text>暂时不支持</Text> </View>
  }
}
